//
// Created by tyyp- on 11/23/2020.
//

#ifndef MINIMUMSPANNINGTREE_GENERAL_H
#define MINIMUMSPANNINGTREE_GENERAL_H

#include<climits>

// Denote the distance between 2 vertices without an edge.
const int INFINITY = INT_MAX;


#endif //MINIMUMSPANNINGTREE_GENERAL_H
